<?php
/**
 * Services archives template
 *
 * @package Product_Showcase
 */

get_header(); ?>

	<?php //do_action('sydney_before_content'); ?>

	<div id="primary" class="content-area">
		<main id="main" class="post-wrap roll-team no-carousel" role="main">

		<?php the_widget( 'Menu_Products' ); ?>



<?php get_footer(); ?>
